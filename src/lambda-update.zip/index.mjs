import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, ScanCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({ region: "ap-northeast-1" });
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = "yokohama-posters";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,PUT,OPTIONS'
};

export const handler = async (event) => {
  console.log('Event:', JSON.stringify(event));
  
  const path = event.path || event.rawPath;
  const method = event.httpMethod || event.requestContext?.http?.method;
  
  // OPTIONS（CORS対応）
  if (method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }
  
  try {
    // ステータス更新（新規追加）
    if (path === '/update-status' && method === 'PUT') {
      const body = JSON.parse(event.body);
      
      const updateCommand = new UpdateCommand({
        TableName: TABLE_NAME,
        Key: {
          pk: 'POSTER',
          sk: body.posterNumber
        },
        UpdateExpression: 'SET #status = :status',
        ExpressionAttributeNames: {
          '#status': 'status'
        },
        ExpressionAttributeValues: {
          ':status': body.status
        }
      });
      
      await docClient.send(updateCommand);
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({ success: true })
      };
    }
    
    // 全ポスター取得（既存）
    if (path === '/posters' && method === 'GET') {
      const scanCommand = new ScanCommand({
        TableName: TABLE_NAME,
        FilterExpression: 'pk = :pk',
        ExpressionAttributeValues: {
          ':pk': 'POSTER'
        }
      });
      
      const result = await docClient.send(scanCommand);
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(result.Items || [])
      };
    }
    
    return {
      statusCode: 404,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Not found' })
    };
    
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message })
    };
  }
};